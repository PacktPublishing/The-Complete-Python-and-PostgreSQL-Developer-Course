# -python-postgresql-
the-complete-python-postgresql-developer-course
https://www.udemy.com/the-complete-python-postgresql-developer-course/
