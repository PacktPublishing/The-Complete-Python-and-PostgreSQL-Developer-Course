CONSUMER_KEY = '6rMEPcsKZDNpNxKsY6hfNl6PY'
CONSUMER_SECRET = '3B2V3xiYA2q0MQmPsuDQwCPdWqZccJiHlpC45dI07i8ulJMehh'

REQUEST_TOKEN_URL = 'https://api.twitter.com/oauth/request_token'
ACCESS_TOKEN_URL = 'https://api.twitter.com/oauth/access_token'
AUTHORIZATION_URL = 'https://api.twitter.com/oauth/authorize'
